#!/bin/bash

# Set your Ansible Galaxy login and API key
GALAXY_LOGIN="marchgroup2023"
API_KEY= " 44fd8cd9cdbaf7784c2c8259b5808ea2a53993ce "

# Set the collection name and version
COLLECTION_NAME="project"
COLLECTION_VERSION=$(ansible-galaxy collection info $project --json | jq -r '.versions | .[-1]')

# Set the collection tarball filename
TARBALL_FILENAME="${COLLECTION_NAME}-$project-collection-1.0.0.tar.gz"

# Build the collection tarball
ansible-galaxy collection build $project --force --output-path=./

# Check if the tarball was created successfully
if [ -f "$project-collection-1.0.0.tar.gz" ]; then
  echo "Collection tarball created successfully: $project-collection-1.0.0.tar.gz"
else
  echo "Failed to create collection tarball"
  exit 1
fi

# Login to Ansible Galaxy
ansible-galaxy login --token "$44fd8cd9cdbaf7784c2c8259b5808ea2a53993ce"

# Publish the collection to Ansible Galaxy
ansible-galaxy collection publish --token "$44fd8cd9cdbaf7784c2c8259b5808ea2a53993ce" "$project-collection-1.0.0.tar.gz" -r marchgroup

# Check if the publishing was successful
if [ $? -eq 0 ]; then
  echo "Collection published successfully to Ansible Galaxy"
else
  echo "Failed to publish collection to Ansible Galaxy"
  exit 1
fi
